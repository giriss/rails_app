document.write("<script src=\"http://localhost:3000/assets/jquery.cookie.min.js\"></script>");document.write("<script src=\"http://localhost:3000/assets/website_entry.min.js\"></script>");
